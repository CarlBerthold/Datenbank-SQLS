package IG_02_Strategy_01_Basic;

public class Context
{
	private IStrategy strategy;

	public IStrategy getStrategy()
	{
		return strategy;
	}

	public void setStrategy(IStrategy strategy)
	{
		this.strategy = strategy;
	} 
	
	public int execute(int z, int y)
	{
		return strategy.executeAlgorithm(z, y);
	}
}
