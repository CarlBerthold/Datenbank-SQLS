package IG_04_Adapter_02_Pattern;

public interface ITurkey
{
	public void gobble();
	
	public void fly();

}
