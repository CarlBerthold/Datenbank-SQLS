package IG_04_Adapter_01_Basic;

public class MallardDuck implements IDuck
{
	@Override
	public void quack()
	{
		System.out.println("Quak");
	}

	@Override
	public void fly()
	{
		System.out.println("Ich fliege");
	}
}
