package IG_03_Observer_02_Pattern_2;

public interface IBeobachter 
{
	public void update(int value);
}
