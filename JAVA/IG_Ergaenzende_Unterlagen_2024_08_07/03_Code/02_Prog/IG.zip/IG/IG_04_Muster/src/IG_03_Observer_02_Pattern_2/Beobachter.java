package IG_03_Observer_02_Pattern_2;

import java.util.ArrayList;

public class Beobachter implements IBeobachter
{
	private int value;
	
	// --------------------------------------------------------------------------
	private IDaten idaten;
	
	public Beobachter(IDaten idaten) 
	{
		this.idaten = idaten;
		idaten.listeAnmelden(this);
	}
	
	@Override
	public void update(int value) 
	{
		this.value = value;
		display();
	}
	
	// -------------------------------------------------------------------------
	public void display() 
	{
		System.out.println("Value: " + value);
	}
}
