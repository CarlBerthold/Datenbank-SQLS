package IG_04_Adapter_01_Basic;

public class DuckSimulator
{
	public static void main(String[] args)
	{
		IDuck duck = new MallardDuck();
		testDuck(duck);
		
		ITurkey turkey = new WildTrukey();
		
		// ES GEHT NICHT !!!
		// testDuck(turkey);
	}
	
	public static void testDuck(IDuck duck)
	{
		duck.quack();
		duck.fly();
	}
}
