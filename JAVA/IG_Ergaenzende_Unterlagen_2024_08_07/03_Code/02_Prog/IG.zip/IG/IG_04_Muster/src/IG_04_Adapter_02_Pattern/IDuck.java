package IG_04_Adapter_02_Pattern;

public interface IDuck
{
	public void quack();
	
	public void fly();
}
