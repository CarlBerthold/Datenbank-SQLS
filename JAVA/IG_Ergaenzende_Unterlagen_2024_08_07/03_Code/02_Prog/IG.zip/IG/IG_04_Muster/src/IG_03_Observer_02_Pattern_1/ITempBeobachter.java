package IG_03_Observer_02_Pattern_1;

public interface ITempBeobachter
{
	public void geanderteTemperatur(int temperatur);
}
