package IG_04_Adapter_02_Pattern;

public class MallardDuck implements IDuck
{
	@Override
	public void quack()
	{
		System.out.println("Duck: Quak");
	}

	@Override
	public void fly()
	{
		System.out.println("Duck: Ich fliege");
		
	}
}
