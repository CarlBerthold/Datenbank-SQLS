package IG_02_Strategy_01_Basic;

public interface IStrategy
{
	public int executeAlgorithm(int z,int y); 
}