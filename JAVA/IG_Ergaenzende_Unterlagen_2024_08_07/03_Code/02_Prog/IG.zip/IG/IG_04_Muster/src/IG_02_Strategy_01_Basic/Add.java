package IG_02_Strategy_01_Basic;

public class Add implements IStrategy
{
	@Override
	public int executeAlgorithm(int z, int y)
	{
		return z + y;
	}
}
