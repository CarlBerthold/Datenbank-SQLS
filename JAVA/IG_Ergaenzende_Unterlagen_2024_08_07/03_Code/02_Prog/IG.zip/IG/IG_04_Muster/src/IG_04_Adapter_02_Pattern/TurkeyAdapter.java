package IG_04_Adapter_02_Pattern;

public class TurkeyAdapter implements IDuck
{
	private ITurkey iturkey;
	
	public TurkeyAdapter(ITurkey iturkey)
	{
		this.iturkey = iturkey;
	}

	@Override
	public void quack()
	{
		iturkey.gobble();
	}

	@Override
	public void fly()
	{
		iturkey.fly();
	}
}
