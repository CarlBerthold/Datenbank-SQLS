package IG_01_Singelton_01_Basic;

public class Program
{
	public static void main(String[] args)
	{
		System.out.println(Person.getInstancee());
		System.out.println(Person.getInstancee());
		System.out.println(Person.getInstancee());
		System.out.println(Person.getInstancee());
		System.out.println(Person.getInstancee());
	}
}
