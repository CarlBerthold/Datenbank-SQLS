package IG_04_Adapter_01_Basic;

public interface ITurkey
{
	public void gobble();
	
	public void fly();
}
