package IG_03_Observer_02_Pattern_2;

import java.util.ArrayList;
import java.util.List;

public class Daten implements IDaten
{
	private List<IBeobachter> listeBeobachter;
	
	private int value = 0;
	
	public Daten() 
	{
		listeBeobachter = new ArrayList<IBeobachter>();
	}
	
	public void listeAnmelden(IBeobachter beobachter) 
	{
		listeBeobachter.add(beobachter);
	}
	
	public void listeAbmelden(IBeobachter beobachter) 
	{
		listeBeobachter.remove(beobachter);
	}
	
	public void informiereAlleBeobachter() {
		for (IBeobachter observer : listeBeobachter) 
		{
			observer.update(value);
		}
	}
	
	public void setValue(int value) 
	{
		this.value = value;
		informiereAlleBeobachter();
	}
}