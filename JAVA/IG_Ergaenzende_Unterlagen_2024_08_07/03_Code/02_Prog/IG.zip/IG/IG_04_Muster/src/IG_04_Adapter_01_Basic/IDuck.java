package IG_04_Adapter_01_Basic;

public interface IDuck
{
	public void quack();
	
	public void fly();
}
