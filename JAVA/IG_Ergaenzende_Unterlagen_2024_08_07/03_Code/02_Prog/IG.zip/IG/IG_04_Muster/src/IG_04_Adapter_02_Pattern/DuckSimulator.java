package IG_04_Adapter_02_Pattern;

public class DuckSimulator
{
	public static void main(String[] args)
	{
		IDuck duck = new MallardDuck();
		testDuck(duck);
		
		ITurkey iturkey = new WildTrukey();
		
		IDuck iTurkeyAdapter = new TurkeyAdapter(iturkey);
		
		testDuck(iTurkeyAdapter);	
	}
	
	public static void testDuck(IDuck duck)
	{
		duck.quack();
		duck.fly();
	}
}
