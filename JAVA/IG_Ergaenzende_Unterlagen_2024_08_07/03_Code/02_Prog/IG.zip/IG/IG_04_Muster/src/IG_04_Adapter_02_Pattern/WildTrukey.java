package IG_04_Adapter_02_Pattern;

public class WildTrukey implements ITurkey
{
	@Override
	public void gobble()
	{
		System.out.println("Turkey: Gobble gobble");
	}

	@Override
	public void fly()
	{
		System.out.println("Turkey: Ich flige eine kurzes Stück.");
	}
}
