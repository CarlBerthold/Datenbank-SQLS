package IG_03_Observer_02_Pattern_2;

public class Program 
{
	public static void main(String[] args) 
	{
		Daten daten = new Daten();
		
		Beobachter beobachter = new Beobachter(daten);

		daten.setValue(80);
		
		
		
	//	daten.removeObserver(beobachter);
	}
}
