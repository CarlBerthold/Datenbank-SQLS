package IG_01_Singelton_02_Pattern;

public class Program
{
	public static void main(String[] args)
	{
		System.out.println(Person.getInstance());
		System.out.println(Person.getInstance());
		System.out.println(Person.getInstance());
		System.out.println(Person.getInstance());
		System.out.println(Person.getInstance());
	}

}
