package IG_04_Adapter_01_Basic;

public class WildTrukey implements ITurkey
{
	@Override
	public void gobble()
	{
		System.out.println("Gobble gobble");
	}

	@Override
	public void fly()
	{
		System.out.println("Ich flige eine kurzes Stück.");
	}
}
