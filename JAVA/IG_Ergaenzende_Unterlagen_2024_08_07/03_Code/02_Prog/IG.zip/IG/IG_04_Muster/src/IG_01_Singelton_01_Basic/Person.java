package IG_01_Singelton_01_Basic;

public class Person
{
	public static Person getInstancee()
	{
//		Person p = new Person(); 
//		
//		return p;
		
		return new Person();
	}
}
