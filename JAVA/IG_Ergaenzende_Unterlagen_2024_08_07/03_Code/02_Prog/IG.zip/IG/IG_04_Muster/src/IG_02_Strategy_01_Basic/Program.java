package IG_02_Strategy_01_Basic;

public class Program
{
	public static void main(String[] args)
	{
		int erg = 0;
		
		Add add = new Add();
		Multi multi = new Multi();
		Sub sub = new Sub();
		
		Context context = new Context();
		
		context.setStrategy(sub);
		
		erg = context.execute(10, 3);
		
		System.out.println(erg);
	}
}