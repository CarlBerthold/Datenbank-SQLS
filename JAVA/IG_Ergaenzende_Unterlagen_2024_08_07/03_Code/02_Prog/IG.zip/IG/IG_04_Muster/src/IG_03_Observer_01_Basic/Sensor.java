package IG_03_Observer_01_Basic;

public class Sensor
{
	private int neueTemperatur;
	
	private Heizung heizung;
	private Klima klima;
	
	public Sensor(Heizung heizung, Klima klima )
	{
		this.heizung = heizung;
		this.klima = klima;
	}
	
	public void setTemp (int neueTemperatur)
	{
		this.neueTemperatur = neueTemperatur;
		heizung.geanderteTemperatur(neueTemperatur);
		klima.geanderteTemperatur(neueTemperatur);	
	}
}
