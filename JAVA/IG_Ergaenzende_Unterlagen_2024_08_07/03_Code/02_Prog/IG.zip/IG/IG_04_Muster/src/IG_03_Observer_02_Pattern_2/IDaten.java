package IG_03_Observer_02_Pattern_2;

public interface IDaten 
{
	public void listeAnmelden(IBeobachter beobachter);
	public void listeAbmelden(IBeobachter beobachter);
	public void informiereAlleBeobachter();
}
