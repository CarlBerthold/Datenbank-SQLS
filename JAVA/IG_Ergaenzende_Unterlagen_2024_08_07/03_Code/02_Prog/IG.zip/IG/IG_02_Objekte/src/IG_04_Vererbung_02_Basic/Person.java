package IG_04_Vererbung_02_Basic;

public class Person extends Lebewesen
{	
	public String lieblingFarbe;
}