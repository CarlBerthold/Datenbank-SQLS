package IG_06_Inter_01_Basic;

public class Person implements IVertrag // Vertragsnehmer
{
	@Override
	public void tueWas()
	{
		System.out.println("...");
	}
}
