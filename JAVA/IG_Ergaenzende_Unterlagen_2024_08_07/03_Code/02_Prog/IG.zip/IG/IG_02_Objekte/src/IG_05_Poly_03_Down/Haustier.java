package IG_05_Poly_03_Down;

public class Haustier extends Lebewesen
{
	private boolean darfRaus;
	public boolean getDarfRaus()
	{
		return darfRaus;
	}
	public void setDarfRaus(boolean darfRaus)
	{
		this.darfRaus = darfRaus;
	}
}