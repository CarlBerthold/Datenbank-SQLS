package IG_04_Vererbung_01_Object;

public class Person // extends Object
{	

}