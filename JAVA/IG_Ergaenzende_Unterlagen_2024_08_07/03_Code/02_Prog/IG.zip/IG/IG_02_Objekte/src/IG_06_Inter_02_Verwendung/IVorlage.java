package IG_06_Inter_02_Verwendung;

public interface IVorlage
{
	public int berechneZweiZahlen(int zahlEins, int zahlZwei);
}
