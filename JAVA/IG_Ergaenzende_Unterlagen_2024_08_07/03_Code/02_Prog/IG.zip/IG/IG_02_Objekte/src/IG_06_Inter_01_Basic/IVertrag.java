package IG_06_Inter_01_Basic;

public interface IVertrag 		// Vertragsgeber
{
	public void tueWas();
}
