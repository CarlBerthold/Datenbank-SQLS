package IG_06_Inter_02_Verwendung;

public class Sub implements IVorlage
{

	@Override
	public int berechneZweiZahlen(int zahlEins, int zahlZwei)
	{
		return zahlEins - zahlZwei;
	}

}
