package IG_04_Vererbung_02_Basic;

public class Lebewesen // extends Object
{
	public String name;
	public int alter;
}