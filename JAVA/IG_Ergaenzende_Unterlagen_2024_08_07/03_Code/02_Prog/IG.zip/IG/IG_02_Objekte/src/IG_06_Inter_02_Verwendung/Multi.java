package IG_06_Inter_02_Verwendung;

public class Multi implements IVorlage
{
	public int berechneZweiZahlen(int zahlEins, int zahlZwei)
	{
		return zahlEins * zahlZwei;
	}
}