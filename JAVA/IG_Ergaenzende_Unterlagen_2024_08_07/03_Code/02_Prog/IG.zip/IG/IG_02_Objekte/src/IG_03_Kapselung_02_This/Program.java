package IG_03_Kapselung_02_This;

public class Program
{
	public static void main(String[] args)
	{	
		Person person = new Person();
		
		person.setName("Hannelore");
		
		System.out.println(person.getName());
	}
}
