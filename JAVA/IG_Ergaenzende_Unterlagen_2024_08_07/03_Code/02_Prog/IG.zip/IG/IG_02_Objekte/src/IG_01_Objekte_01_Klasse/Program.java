package IG_01_Objekte_01_Klasse;

public class Program
{
	public static void main(String[] args)
	{
		Person objPerson;
		objPerson = new Person();
		
		objPerson.name = "Jenny";
		objPerson.alter = 33;
		
		objPerson.gibInfos();
	}
}