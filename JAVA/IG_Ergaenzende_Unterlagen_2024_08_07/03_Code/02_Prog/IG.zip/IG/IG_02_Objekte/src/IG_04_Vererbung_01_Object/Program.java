package IG_04_Vererbung_01_Object;

public class Program
{
	public static void main(String[] args)
	{			
		Person person = new Person();
		
		System.out.println(person.toString());
	}
}
