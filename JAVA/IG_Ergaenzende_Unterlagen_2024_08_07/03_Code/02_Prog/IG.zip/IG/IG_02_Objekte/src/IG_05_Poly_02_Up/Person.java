package IG_05_Poly_02_Up;

public class Person extends Lebewesen
{	
	private String lieblingsFarbe;	
	public String getLieblingsFarbe()
	{
		return lieblingsFarbe;
	}
	public void setLieblingsFarbe(String lieblingsFarbe)
	{
		this.lieblingsFarbe = lieblingsFarbe;
	}
}