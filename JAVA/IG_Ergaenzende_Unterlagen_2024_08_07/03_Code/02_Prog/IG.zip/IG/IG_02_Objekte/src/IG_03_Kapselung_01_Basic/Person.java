package IG_03_Kapselung_01_Basic;


public class Person
{
	private String name;
	
	public void setName(String paraName)
	{
		name = paraName;
	}
	
	public String getName()
	{
		return name;
	}
}