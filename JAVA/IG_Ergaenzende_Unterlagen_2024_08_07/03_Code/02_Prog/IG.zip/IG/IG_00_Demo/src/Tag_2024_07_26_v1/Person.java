package Tag_2024_07_26_v1;

public class Person
{
	private String name;	
	private int alter;
	
	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public int getAlter()
	{
		return alter;
	}

	public void setAlter(int alter)
	{
		this.alter = alter;
	}

}
