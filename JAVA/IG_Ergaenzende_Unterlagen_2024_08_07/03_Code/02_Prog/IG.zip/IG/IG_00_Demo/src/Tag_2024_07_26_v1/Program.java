package Tag_2024_07_26_v1;

import java.util.Scanner;

public class Program
{

	public static void main(String[] args)
	{
	
	}
	
}
