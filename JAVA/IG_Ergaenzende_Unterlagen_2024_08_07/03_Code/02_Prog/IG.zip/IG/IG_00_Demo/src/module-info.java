/**
 * 
 */
/**
 * 
 */
module xDemo
{
	requires java.desktop;
	requires java.sql;
}