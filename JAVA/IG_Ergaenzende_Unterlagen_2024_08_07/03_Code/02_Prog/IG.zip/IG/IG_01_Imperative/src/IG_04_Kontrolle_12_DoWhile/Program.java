package IG_04_Kontrolle_12_DoWhile;

public class Program
{
	public static void main(String[] args)
	{
		boolean pruefung = false;
		
		do
		{
			System.out.println("Hannelore");
		}
		while (pruefung);
		
		System.out.println("Ende");
	}
}