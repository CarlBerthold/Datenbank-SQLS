package IG_00_Start;

// In OOP befindet sich alles in einer Klassen.
public class Program
{
	// Haupteinstieg einer Java-Applikation.
	public static void main(String[] args)
	{
		/*
		
		
		
		 */
		
		
		System.out.println("Hello World!");
	}
}