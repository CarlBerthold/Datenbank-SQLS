package IG_01_Daten_01_Typen;

public class Program
{
	public static void main(String[] args)
	{
		// Deklarrieren		-->	  	DT name;
		int zahl;
		
		// Init. 			--> 	variable = wert;
		zahl = 0;
		
		// Dekl. + Init.	
		int wert = 33;
		
		System.out.println(zahl);
		System.out.println(wert);	
	}
}