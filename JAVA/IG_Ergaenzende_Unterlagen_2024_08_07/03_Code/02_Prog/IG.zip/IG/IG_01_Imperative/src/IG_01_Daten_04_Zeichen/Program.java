package IG_01_Daten_04_Zeichen;

public class Program
{
	public static void main(String[] args)
	{				
		// char ------------------------------------------------------		16 - BIT	
		char charWert = '0';
		
		System.out.println(charWert);
	}
}