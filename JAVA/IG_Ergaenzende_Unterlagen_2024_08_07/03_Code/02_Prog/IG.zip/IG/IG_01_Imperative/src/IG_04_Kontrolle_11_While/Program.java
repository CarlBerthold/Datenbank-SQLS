package IG_04_Kontrolle_11_While;

public class Program
{
	public static void main(String[] args)
	{
		boolean pruefung = true;
		
		while (pruefung)
		{
			System.out.println("Hannelore");
		}
		
		System.out.println("Ende");
		
	}
}