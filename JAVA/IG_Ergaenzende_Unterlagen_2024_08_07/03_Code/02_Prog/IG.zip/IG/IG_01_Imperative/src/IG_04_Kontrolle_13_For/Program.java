package IG_04_Kontrolle_13_For;

public class Program
{
	public static void main(String[] args)
	{
		for (int i = 0; i < 3; i++)
		{
			System.out.println("Hannelore");
		}
	}
}