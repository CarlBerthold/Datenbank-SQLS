package IG_01_Daten_06_String;

public class Program
{
	public static void main(String[] args)
	{				
		// String ------------------------------------------------------		16 + 16 + 16 + 16 + 16 - BIT	
		String stringWert = "Hans";

		System.out.println(stringWert);
	}
}