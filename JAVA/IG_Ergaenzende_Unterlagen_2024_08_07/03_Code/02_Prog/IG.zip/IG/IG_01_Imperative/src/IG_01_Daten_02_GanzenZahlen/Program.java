package IG_01_Daten_02_GanzenZahlen;

public class Program
{
	public static void main(String[] args)
	{
		// byte  ------------------------------------------------------			 8 - BIT
//		byte byteWert = 0;
//		
//		byteWert = Byte.MIN_VALUE;
//		System.out.println(byteWert);
//		
//		byteWert = Byte.MAX_VALUE;
//		System.out.println(byteWert);
		
		// short  ------------------------------------------------------		16 - BIT	
//		short shortWert = 0;
//		
//		shortWert = Short.MIN_VALUE;
//		System.out.println(shortWert);
//		
//		shortWert = Short.MAX_VALUE;
//		System.out.println(shortWert);
		
		// int  --------------------------------------------------------		32 - BIT	
		int intWert = 0;
		
		intWert = Integer.MIN_VALUE;
		System.out.println(intWert);
		
		intWert = Integer.MAX_VALUE;
		System.out.println(intWert);
		
		// long  --------------------------------------------------------		64 - BIT	
//		long longWert = 0;
//		
//		longWert = Long.MIN_VALUE;
//		System.out.println(longWert);
//		
//		longWert = Long.MAX_VALUE;
//		System.out.println(longWert);
	}
}