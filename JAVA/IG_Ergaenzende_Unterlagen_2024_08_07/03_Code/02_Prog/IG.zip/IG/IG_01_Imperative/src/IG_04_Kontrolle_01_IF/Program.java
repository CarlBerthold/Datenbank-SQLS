package IG_04_Kontrolle_01_IF;

public class Program
{
	public static void main(String[] args)
	{
		boolean pruefung = false;
		
		if (pruefung == true)
		{
			System.out.println("Ergebnis: " + pruefung);
		}
		else if(pruefung == false)
		{
			System.out.println("Ergebnis: " + pruefung);
		}
		else 
		{
			System.out.println("Standard");
		}
	}
}