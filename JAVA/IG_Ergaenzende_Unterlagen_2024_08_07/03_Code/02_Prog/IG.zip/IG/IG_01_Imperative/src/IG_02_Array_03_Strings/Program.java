package IG_02_Array_03_Strings;

public class Program
{
	public static void main(String[] args)
	{	
		String name;
		name = "Brückner";
		
		System.out.println(name.length());
		
		for (int i = 0; i < name.length() ; i++)
		{
			System.out.println("Buchstabe: " + name.charAt(i));
		}		
	}
}