package IG_01_Daten_03_KommaZahlen;

public class Program
{
	public static void main(String[] args)
	{		
		// float -------------------------------------------------------		32 - BIT	
		float floatWert = 0.0f;
		
		floatWert = Float.MIN_VALUE;
		System.out.println(floatWert);
		
		floatWert = Float.MAX_VALUE;
		System.out.println(floatWert);
		
		// double ------------------------------------------------------		64 - BIT	
//		double doubleWert = 0.0;
//		
//		doubleWert = Double.MIN_VALUE;
//		System.out.println(doubleWert);
//		
//		doubleWert = Double.MAX_VALUE;
//		System.out.println(doubleWert);
	}
}