package IG_01_Daten_10_Output;

public class Program
{
	public static void main(String[] args)
	{
		// 	OUTPUT:		ALLES RICHTUNG KONSOLE WIRD IN EIN STRING VERWANDELT.
	
		int ganzeZahl = 33;
		double kommaZahl = 7.5;
		boolean pruefung = true;
		
		System.out.println(ganzeZahl);
		System.out.println(kommaZahl);
		System.out.println(pruefung);
	}
}