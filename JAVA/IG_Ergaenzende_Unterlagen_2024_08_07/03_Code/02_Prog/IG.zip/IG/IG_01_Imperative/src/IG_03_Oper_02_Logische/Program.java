package IG_03_Oper_02_Logische;

public class Program
{

	public static void main(String[] args)
	{
		boolean trueOne = true;
		boolean falseTwo = false;
		boolean trueFalseResult;
		
		// Negation
//		trueFalseResult = !trueOne;
//		System.out.println("trueOne: " + trueFalseResult);
//		trueFalseResult = !falseTwo;
//		System.out.println("falseTwo: " + trueFalseResult);
		
//		// AND - & - &&
//		trueFalseResult = false && false ;
//		System.out.println("0 AND 0: " + trueFalseResult);
//		
//		trueFalseResult = false && true ;
//		System.out.println("0 AND 1: " + trueFalseResult);
//		
//		trueFalseResult = true && false ;
//		System.out.println("1 AND 0: " + trueFalseResult);
//
//		trueFalseResult = true && true ;
//		System.out.println("1 AND 1: " + trueFalseResult);

//		// OR - | - ||
//		trueFalseResult = false || false ;
//		System.out.println("0 OR 0: " + trueFalseResult);
//		
//		trueFalseResult = false || true ;
//		System.out.println("0 OR 1: " + trueFalseResult);
//		
//		trueFalseResult = true || false ;
//		System.out.println("1 OR 0: " + trueFalseResult);
//		
//		trueFalseResult = true || true ;
//		System.out.println("1 OR 1: " + trueFalseResult);
		
//		// PRIORITÄTEN 0.Klammern 1.Negation 2.AND 3.OR
//		trueFalseResult = true || true && false;
//		System.out.println("1 OR 1 AND 0: " + trueFalseResult);
//		trueFalseResult = (true || true) && false;
//		System.out.println("1 OR (1 AND 0): " + trueFalseResult);
//		trueFalseResult = (true || true) && false;
//		System.out.println("(1 OR 1) AND 0: " + trueFalseResult);
	}
}
