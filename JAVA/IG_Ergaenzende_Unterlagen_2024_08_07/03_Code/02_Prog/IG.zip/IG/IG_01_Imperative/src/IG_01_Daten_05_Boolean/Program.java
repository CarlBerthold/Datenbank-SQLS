package IG_01_Daten_05_Boolean;

public class Program
{
	public static void main(String[] args)
	{				
		// boolean ------------------------------------------------------		X - BIT	
		boolean boolWert = true;
		
		System.out.println(boolWert);
		
		// umkehren
		boolWert = !boolWert;
		
		System.out.println(boolWert);
	}
}