package IG_02_Lambda_00_Inter;

public class Program
{
	public static void main(String[] args)
	{
//		// Version 1 -------------------------------
//		INachricht schnittstelle;
//		Nachricht objekt = new Nachricht();
//		
//		schnittstelle = objekt;
//		
//		schnittstelle.gibNachrichtAus();
		
		// Version 2 -------------------------------
		
		INachricht schnittstelle = new Nachricht();
		
		schnittstelle.gibNachrichtAus();
	}
}
