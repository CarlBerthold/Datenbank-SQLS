package IG_01_Liste_02_Generics;

public class SinglyLinkedList<T>
{
	private Node<T> first;
	
	public boolean isEmpty()
	{
		boolean proof = (first == null); 
		
		return proof;
	}
	
	public void insertFirst(T data)
	{
		Node<T> newNode = new Node<T>();
		
		newNode.data = data;
		newNode.next = first;
		
		first = newNode;
	}
	
	public Node<T> deleteFirst()
	{
		Node<T> temp = first;
		first = first.next;
		
		return temp;
	}
	
	public void insertLast(T data)
	{
		if(isEmpty())
		{
			insertFirst(data);
		}
		else
		{
			Node<T> current = first;
			
			while(current.next != null) 
			{
				current = current.next;
			}
			
			Node<T> newNode = new Node<T>();
			
			newNode.data = data;
			current.next = newNode;
		}
		
	}
	
	public void displayList()
	{
		System.out.println("Ausgabe: ");
		
		Node<T> current = first;
		
		while(current != null)
		{
			current.displayNode();
			current = current.next;
		}
	}

}
