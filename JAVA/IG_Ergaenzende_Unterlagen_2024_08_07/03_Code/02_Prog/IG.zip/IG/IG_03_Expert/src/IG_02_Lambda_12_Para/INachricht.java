package IG_02_Lambda_12_Para;

@ FunctionalInterface
public interface INachricht
{
	void gibNachrichtAus(String nachricht, int temperatur);
}
