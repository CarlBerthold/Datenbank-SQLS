package IG_02_Lambda_14_util;

import java.util.function.IntBinaryOperator;

public class Program
{
	public static void main(String[] args)
	{
		int ergebnis = 0;
		
		IntBinaryOperator schnittstelle = (int x, int y) -> 
		{
			int faktor = 3;
			
			return (x + y) * faktor; 
		};
		
		ergebnis = schnittstelle.applyAsInt(3, 7);
		
		System.out.println("Ergbenis: " + ergebnis);
	}
}