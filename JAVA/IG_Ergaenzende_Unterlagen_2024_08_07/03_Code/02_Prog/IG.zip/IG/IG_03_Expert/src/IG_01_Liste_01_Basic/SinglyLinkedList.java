package IG_01_Liste_01_Basic;

public class SinglyLinkedList
{
	private Node first;
	
	public boolean isEmpty()
	{
		boolean proof = (first == null); 
		
		return proof;
	}
	
	public void insertFirst(String data)
	{
		Node newNode = new Node();
		
		newNode.data = data;
		newNode.next = first;
		
		first = newNode;
	}
	
	public Node deleteFirst()
	{
		Node temp = first;
		first = first.next;
		
		return temp;
	}
	
	public void insertLast(String data)
	{	
		if (isEmpty())
		{
			insertFirst(data);
		}
		else
		{
			Node current = first;
			
			while(current.next != null) 
			{
				current = current.next;
			}
			
			Node newNode = new Node();
			
			newNode.data = data;
			current.next = newNode;
		}	
	}
	
	public void displayList()
	{
		System.out.println("Ausgabe: ");
		
		Node current = first;
		
		while(current != null)
		{
			current.displayNode();
			current = current.next;
		}
	}

}
