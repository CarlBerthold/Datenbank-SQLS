package IG_01_Liste_01_Basic;

public class Node
{
	public String data;
	public Node next;
	
	public void displayNode()
	{
		System.out.println(data);
	}
}
