package IG_02_Lambda_02_Anonym;

public class Program
{
	public static void main(String[] args)
	{
		INachricht schnittstelle = new INachricht()
		{	
			@Override
			public void gibNachrichtAus()
			{
				System.out.println("Nachricht: Am Wochenende steigt die Temperatur.");
			}
		};
		
		schnittstelle.gibNachrichtAus();
	}
}
