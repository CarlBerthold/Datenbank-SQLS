package IG_02_Lambda_00_Inter;

public class Nachricht implements INachricht
{
	@Override
	public void gibNachrichtAus()
	{
		System.out.println("Nachricht: Am Wochenende steigt die Temperatur.");
	}
}