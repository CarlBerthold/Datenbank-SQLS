package IG_01_Liste_01_Basic;

import java.util.ArrayList;

public class Program
{

	public static void main(String[] args)
	{
//		SinglyLinkedList myList = new SinglyLinkedList();
//		myList.insertFirst("Hans");
//		myList.insertFirst("Petra");
//		myList.insertFirst("Hannelore");
//		myList.insertFirst("Alf");
//		
//		myList.displayList();
		
		SinglyLinkedList myList = new SinglyLinkedList();
		myList.insertLast("Hans");
		myList.insertLast("Petra");
		myList.insertLast("Hannelore");
		myList.insertLast("Alf");
		
		myList.displayList();
	}
}