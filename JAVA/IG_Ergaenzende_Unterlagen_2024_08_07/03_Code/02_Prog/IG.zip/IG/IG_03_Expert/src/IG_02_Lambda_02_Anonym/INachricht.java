package IG_02_Lambda_02_Anonym;

@FunctionalInterface
public interface INachricht
{
	void gibNachrichtAus();
}
