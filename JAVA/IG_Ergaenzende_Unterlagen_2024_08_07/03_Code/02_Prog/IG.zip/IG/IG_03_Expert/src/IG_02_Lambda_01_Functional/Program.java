package IG_02_Lambda_01_Functional;

public class Program
{
	public static void main(String[] args)
	{
//		// Version 1 -------------------------------
//		INachricht schnittstelle = new Nachricht();
//		
//		schnittstelle.gibNachrichtAus();
		
		// Version 2 -------------------------------
		
		INachricht schnittstelle = new INachricht()
		{	
			@Override
			public void gibNachrichtAus()
			{
				System.out.println("Nachricht: Am Wochenende steigt die Temperatur.");
			}
		};
		
		schnittstelle.gibNachrichtAus();
	}
}
