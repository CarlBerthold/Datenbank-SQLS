package IG_02_Lambda_13_Para_2;

@ FunctionalInterface
public interface ICalc
{
	int add(int numOne, int numTwo);
}
