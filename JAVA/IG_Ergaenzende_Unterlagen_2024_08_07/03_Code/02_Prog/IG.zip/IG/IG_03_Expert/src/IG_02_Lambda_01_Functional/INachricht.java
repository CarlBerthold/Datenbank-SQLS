package IG_02_Lambda_01_Functional;

@ FunctionalInterface
public interface INachricht
{
	void gibNachrichtAus();
	
	// Ein Functional- Interface darf nur eine Methode haben.
	// void gibNachrichtEin(String nachricht);
}
