package IG_03_Streams_01_Basic;

import java.util.ArrayList;
import java.util.Collections;

public class Program
{
	public static void main(String[] args)
	{
		ArrayList<String> listCountry = new ArrayList<String> ();
		listCountry.add("italy");
		listCountry.add(" spain");
		listCountry.add("german");
		listCountry.add("china");
		
		// Version 1 -----------------------------------------------------------------------------
		
//		Collections.sort(listCountry);
//		
//		for (String country : listCountry)
//		{
//			country = country.toUpperCase();
//			
//			if(!country.startsWith(" "))
//			{
//				System.out.println(country);
//			}			
//		}
		
		// Version 2 -----------------------------------------------------------------------------
		listCountry.stream()
		.map( s -> s.toUpperCase())
		.filter( s -> !s.startsWith(" "))
		.sorted()
		.forEach(s -> System.out.println(s));
		
		/*
			Wichtig:
					1. Sie können intermediate (typ als return) / terminal (void als return)
					2. Terminal müssen am ende sein  
					3. Sie sind immutable (nicht mehr änderbar)
		 */
	}
}
