package IG_02_Lambda_11_Basic;

@ FunctionalInterface
public interface INachricht
{
	void gibNachrichtAus();
}
