package IG_02_Lambda_00_Inter;

public interface INachricht
{
	void gibNachrichtAus();
}
