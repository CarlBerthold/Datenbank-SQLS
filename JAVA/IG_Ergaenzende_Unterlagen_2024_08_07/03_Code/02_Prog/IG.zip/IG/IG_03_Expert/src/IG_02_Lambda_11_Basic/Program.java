package IG_02_Lambda_11_Basic;

public class Program
{
	public static void main(String[] args)
	{
		INachricht schnittstelle = () -> 
		{ 
			System.out.println("Nachricht: Am Wochenende steigt die Temperatur."); 
		};
		
		schnittstelle.gibNachrichtAus();
	}
}
