package IG_02_Lambda_12_Para;

public class Program
{
	public static void main(String[] args)
	{
		INachricht schnittstelle = (String nachricht, int temperatur) -> 
		{
			System.out.println("Nachricht: " + nachricht + temperatur + " Grad am Wochenende.");
		};
		
		schnittstelle.gibNachrichtAus("Die Temperatur, steigt um ", 5);
	}
}
