package IG_02_Lambda_01_Functional;

public class Nachricht implements INachricht
{
	@Override
	public void gibNachrichtAus()
	{
		System.out.println("Nachricht: Am Wochenende steigt die Temperatur.");
	}
}