package IG_01_Liste_02_Generics;

public class Program
{

	public static void main(String[] args)
	{
		SinglyLinkedList<String> myListText = new SinglyLinkedList<String>();
		myListText.insertLast("Hans");
		myListText.insertLast("Petra");
		myListText.insertLast("Andreas");
		myListText.insertLast("Alf");
		
		myListText.displayList();
		
		
		SinglyLinkedList<Integer> myListZahlen = new SinglyLinkedList<Integer>();
		myListZahlen.insertFirst(33);
		myListZahlen.insertFirst(35435);
		myListZahlen.insertFirst(6);
		myListZahlen.insertFirst(2352);
		
		myListZahlen.displayList();
	}
}