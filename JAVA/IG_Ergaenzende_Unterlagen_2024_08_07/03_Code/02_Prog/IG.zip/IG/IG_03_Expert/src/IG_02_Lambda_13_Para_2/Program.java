package IG_02_Lambda_13_Para_2;

public class Program
{
	public static void main(String[] args)
	{
		int ergebnis = 0;
		
		ICalc schnittstelle = (int x, int y) -> 
		{
			int faktor = 3; 
			return (x + y) * faktor;
		};
		
		ergebnis = schnittstelle.add(3, 7);
		
		System.out.println("Ergbenis: " + ergebnis);
		
	}
}
