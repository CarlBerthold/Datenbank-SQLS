package DBS_01_Verbindung;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Program
{

	public static void main(String[] args) throws SQLException
	{
		String connString = "jdbc:mysql://localhost:3306/sakila";
		String user = "root";
		String pw = "DBS_2024_Kurs";
		
		Connection connection = null;

		try
		{
			connection  = DriverManager.getConnection(connString,user,pw);
			
			System.out.println("Funktioniert");
		}
		
		catch (SQLException e)
		{
			System.out.println("Fehler: " + e.getMessage());
		}
		finally 
		{
			if (connection != null)
			{
				connection.close();
			}		
		}
	}

}
