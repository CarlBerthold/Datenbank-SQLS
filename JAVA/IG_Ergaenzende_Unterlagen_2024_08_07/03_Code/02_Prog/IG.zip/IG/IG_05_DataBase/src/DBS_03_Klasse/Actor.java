package DBS_03_Klasse;

public class Actor
{
	private int idActor;
	private String firstName;
	private String lastName;
	
	public int getIdActor()
	{
		return idActor;
	}
	public void setIdActor(int idActor)
	{
		this.idActor = idActor;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	
	@Override
	public String toString()
	{
		return String.format("ID: %s Name: %s,%s ",getIdActor(),getFirstName(),getLastName());
	}
}
