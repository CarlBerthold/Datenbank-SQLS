package DBS_04_DBSContext;

public class Actor
{
	private int idActor;
	private String firstName;
	private String lastName;
	
	public int getIdActor()
	{
		return idActor;
	}
	public void setIdActor(int idActor)
	{
		this.idActor = idActor;
	}
	
	public String getFirstName()
	{
		firstName = firstName.substring(0, 1).toUpperCase() + firstName.substring(1).toLowerCase();
		return firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	
	public String getLastName()
	{
		lastName = lastName.substring(0, 1).toUpperCase() + lastName.substring(1).toLowerCase();
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	
	@Override
	public String toString()
	{
		if (getIdActor() < 10 )
		{
			return String.format("ID: 00%s Name: %s,%s ",getIdActor(),getFirstName(),getLastName());
		}
		else if(getIdActor() >= 10 && getIdActor() < 100)
		{			
			return String.format("ID: 0%s Name: %s,%s ",getIdActor(),getFirstName(),getLastName());
		}
		else 
		{			
			return String.format("ID: %s Name: %s,%s ",getIdActor(),getFirstName(),getLastName());
		}
	}
}
