package DBS_05_CRUD;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Mapper
{
	public static ArrayList<Actor> actorMapping(ResultSet resultSet)
	{
		ArrayList<Actor> actors = new ArrayList<Actor>();
		
		Actor actor = null;

		try
		{
			
			while(resultSet.next())
			{	
				actor = new Actor();
				
				actor.setIdActor(Integer.parseInt(resultSet.getString("actor_id")));
				actor.setFirstName(resultSet.getString("first_name"));
				actor.setLastName(resultSet.getString("last_Name"));
				
				actors.add(actor);
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
		return actors;
	}
	
	public static ArrayList<FilmText> filmTextMapping(ResultSet resultSet)
	{
		FilmText filmText = null;
		
		ArrayList<FilmText> listefilmText = new ArrayList<FilmText>();
		
		try
		{
			while(resultSet.next())
			{
    			filmText = new FilmText();
    			
    			filmText.setIdFilmText(Integer.parseInt(resultSet.getString("film_id")));
    			filmText.setTitle(resultSet.getString("title"));
    			filmText.setDescription(resultSet.getString("description"));
    			
    			listefilmText.add(filmText);
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listefilmText;
	}
}