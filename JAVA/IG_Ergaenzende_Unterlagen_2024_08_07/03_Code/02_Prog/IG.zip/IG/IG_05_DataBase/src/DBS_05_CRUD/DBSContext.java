package DBS_05_CRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBSContext
{
	public static String connectionString = "jdbc:mysql://localhost:3306/sakila";
	public static String user = "root";
	public static String pw = "DBS_2024_Kurs";
	
	public static ResultSet getTableFromServer(String tabelle)
	{
		Connection conn = null;
		Statement stm = null;
		ResultSet rs = null;
		
		String mySelect = String.format("select * from %s", tabelle);
		
		try
		{
			conn = DriverManager.getConnection(connectionString,user,pw);
			stm = conn.createStatement();
			rs = stm.executeQuery(mySelect);
		}
		catch (SQLException e)
		{
			System.out.println("DBSConetxt Fehler:" + e.getMessage());
			e.printStackTrace();
		}
		
		return rs;
	}
	
	public static int insertActor(String firstName, String lastName )
	{
		Connection conn = null;
		Statement stm = null;
		ResultSet rs = null;
		
		int row = 0;
		
		String myInsert = String.format("insert Actor (first_name,last_name) values ('%s','%s')", firstName,lastName);
		
		try
		{
			conn = DriverManager.getConnection(connectionString,user,pw);
			stm = conn.createStatement();
			
			row = stm.executeUpdate(myInsert);
		}
		catch (SQLException e)
		{
			System.out.println("DBSConetxt Fehler:" + e.getMessage());
		}
		
		return row;
	}
		
	public static int deleteActor(int idActor)
	{
		Connection conn = null;
		Statement stm = null;
		ResultSet rs = null;
		
		int row = 0;
		
		String myDelete = String.format("delete from Actor where actor_id = %s", idActor);
		
		try
		{
			conn = DriverManager.getConnection(connectionString,user,pw);
			stm = conn.createStatement();
			
			row = stm.executeUpdate(myDelete);
		}
		catch (SQLException e)
		{
			System.out.println("DBSConetxt Fehler:" + e.getMessage());
		}
		
		return row;
	}
}
