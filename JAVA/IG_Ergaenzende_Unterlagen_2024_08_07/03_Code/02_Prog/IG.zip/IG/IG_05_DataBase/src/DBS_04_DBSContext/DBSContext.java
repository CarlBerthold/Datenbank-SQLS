package DBS_04_DBSContext;

import java.sql.*;

public class DBSContext
{
	public static ResultSet getTableFromServer(String tabelle)
	{
		String connectionString = "jdbc:mysql://localhost:3306/sakila";
		String user = "root";
		String pw = "DBS_2024-Kurs!";
		
		String tableName = tabelle;	
		String mySelect = String.format("select * from %s" ,tableName);
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try
		{	
			connection = DriverManager.getConnection(connectionString,user,pw);
			statement = connection.createStatement();	
			resultSet = statement.executeQuery(mySelect);
		}
		catch (SQLException e)
		{
			System.out.println("Fehler: " + e);
		}
		
		return resultSet;
	}
	
}