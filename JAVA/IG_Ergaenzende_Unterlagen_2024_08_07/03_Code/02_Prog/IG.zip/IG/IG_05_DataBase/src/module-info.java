/**
 * 
 */
/**
 * 
 */
module DataBase
{
	requires java.sql;
}