package DBS_05_CRUD;

public class FilmText
{
	private int idFilmText;
	public int getIdFilmText()
	{
		return idFilmText;
	}
	public void setIdFilmText(int idFilmText)
	{
		this.idFilmText = idFilmText;
	}
	
	private String title;
	public String getTitle()
	{
		title = title.substring(0, 1).toUpperCase() + title.substring(1).toLowerCase();
		
		return title;
	}
	public void setTitle(String title)
	{	
		// title = title.substring(0, 1).toUpperCase() + title.substring(1).toLowerCase();
		
		this.title = title;
	}
	
	private String description;
	public String getDescription()
	{
		description = description.substring(0, 1).toUpperCase() + description.substring(1).toLowerCase();
		
		return description;
	}
	public void setDescription(String description)
	{
		// description = description.substring(0, 1).toUpperCase() + description.substring(1).toLowerCase();
		
		this.description = description;
	}
	
    public String toString()
    {
    	String meinReturn = String.format("ID: %s Title: %s Description: %s",getIdFilmText(),getTitle(),getDescription());
    	
    	return meinReturn;
    }
}
