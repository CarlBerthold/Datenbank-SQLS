package DBS_05_CRUD;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Program
{
	public static void main(String[] args)
	{
		ArrayList<Actor> listeActor = Mapper.actorMapping(DBSContext.getTableFromServer("Actor"));
		
		DBSContext.insertActor("Hans", "Mueller");
		
		
		listeActor = Mapper.actorMapping(DBSContext.getTableFromServer("Actor"));
		
		DBSContext.deleteActor(listeActor.getLast().getIdActor());
		
		
		listeActor = Mapper.actorMapping(DBSContext.getTableFromServer("Actor"));
		
		for (Actor actor : listeActor)
		{
			System.out.println(actor);
		}
	}
}
