package DBS_04_DBSContext;

import java.sql.*;
import java.util.ArrayList;

public class ActorMapper
{
	public static ArrayList<Actor> actorMapping(ResultSet resultSet)
	{
		ArrayList<Actor> actors = new ArrayList<Actor>();
		
		Actor actor = null;

		try
		{
			
			while(resultSet.next())
			{	
				actor = new Actor();
				
				actor.setIdActor(Integer.parseInt(resultSet.getString("actor_id")));
				actor.setFirstName(resultSet.getString("first_name"));
				actor.setLastName(resultSet.getString("last_Name"));
				
				actors.add(actor);
			}
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		
		return actors;
	}
}
