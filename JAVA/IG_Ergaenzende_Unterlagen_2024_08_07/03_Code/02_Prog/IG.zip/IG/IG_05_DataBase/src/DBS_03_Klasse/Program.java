package DBS_03_Klasse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Program
{
	public static void main(String[] args) throws SQLException
	{
		String connString = "jdbc:mysql://localhost:3306/sakila";
		String user = "root";
		String pw = "DBS_2024_Kurs";
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		String colName = "*";
		String tblName = "actor";
		
		String mySelect = String.format("select %s from %s", colName, tblName);
		
		Actor actor = new Actor();
		
		try
		{
			connection = DriverManager.getConnection(connString,user,pw);
			
			statement = connection.createStatement();
			
			resultSet = statement.executeQuery(mySelect);
			
			resultSet.next();
			
			actor.setIdActor(resultSet.getInt(1));
			actor.setFirstName(resultSet.getString(2));
			actor.setLastName(resultSet.getString(3));
			
			System.out.println(actor);
		}
		
		catch (SQLException e)
		{
			System.out.println("Fehler: " + e.getMessage());
		}
		finally 
		{
			if (resultSet != null)
			{
				resultSet.close();
			}
			
			if (statement != null)
			{
				statement.close();
			}
			
			if (connection != null)
			{
				connection.close();
			}		
		}
	}

}
