package DBS_04_DBSContext;

import java.sql.*;
import java.util.ArrayList;

public class Program
{

	public static void main(String[] args)
	{	
		ResultSet actorsFromServer = DBSContext.getTableFromServer("actor");
		
		ArrayList<Actor> actors = ActorMapper.actorMapping(actorsFromServer);
		
		// Pruefung
		for (Actor actor : actors)
		{
			System.out.println(actor);
		}
	}
}
