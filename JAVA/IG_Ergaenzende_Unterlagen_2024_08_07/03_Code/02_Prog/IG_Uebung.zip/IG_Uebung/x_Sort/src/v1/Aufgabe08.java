package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class Aufgabe08
{

	public static void main(String[] args)
	{

		// neues Array anlegen, Gr��e von Konsole einlesen und initialisieren
		int[] myArray = getNewArray();

		// Array ausgeben
		if (myArray.length > 0)
		{
			ausgebenArray(myArray);
		} else
		{
			System.out.println("Array ist leer!");
		}
	}

	private static int[] getNewArray()
	{

		// neues Array erzeugen und gr��em von Konsole einlesen
		int[] neuesArray = new int[einlesenArraygroesse()];

		// neues Array initialisieren
		// bei Gr��e 0 wird nicht initialisier da kopfgesteuerte Schleife
		initialisierenArray(neuesArray);

		return neuesArray;
	}

	private static void ausgebenArray(int[] myArray)
	{

		for (int i = 0; i < myArray.length; i++)
		{
			System.out.println("Zeile " + (i + 1) + ": " + myArray[i]);
		}

	}

	private static void initialisierenArray(int[] myArray)
	{

		Random rand = new Random();
		for (int i = 0; i < myArray.length; i++)
		{
			myArray[i] = rand.nextInt();
		}
	}

	private static short einlesenArraygroesse()
	{

		short zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Arraygr��e eingeben:");
		do
		{
			try
			{
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Short.parseShort(input); // throws exception

				if (zahl >= 0)
				{
					isOk = true;
				} else
				{
					System.out.println("Fehler, die Arraygr��e darf nicht negativ sein, \nbitte erneut eingeben:");
					isOk = false;
				}

			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Arraygr��e erneut eingeben:");
				isOk = false;
			}
		} while (!isOk);

		return zahl;
	}

}
