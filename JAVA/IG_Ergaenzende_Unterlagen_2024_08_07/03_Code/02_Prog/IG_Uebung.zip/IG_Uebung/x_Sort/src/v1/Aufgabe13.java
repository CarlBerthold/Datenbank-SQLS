package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Aufgabe13 {

	public static void main(String[] args) {

		//vorgegebenes Array

		//bubble
		int[] myArray = new int[] {24,34,466,1,19,5};
		ausgebenArray(sortierenArray1(myArray));
		
		//quick
		myArray = new int[] {24,34,466,1,19,5};
		ausgebenArray(sortierenArray2(myArray));

		//mit Benutzereingaben
		ausgebenArray(sortierenArray2(initialisierenArray(new int[einlesenArraygroesse()])));
	}

	
	
	private static int[] sortierenArray2(int[] myArray) {
	
		myQSort2(myArray, 0, myArray.length-1);
		
		return myArray;
	}
	private static void myQSort2(int[] array, int start, int ende) {
		
		int l=start, r=ende, hilf=0;

		//zuf�lliges Element aus der Mitte des Arrays, 
		//um die Arraygr��e schnellstm�glich zu verkleinern
		int	pivot = array[(l+r)/2]; 
		
		//einmal das Array durchlaufen (l>r)
		do {
			//von au�en das erste element suchen, dass kleiner/gr��er ist als pivot
			while(l<ende && array[l]<pivot) l++;
			while(r>start && array[r]>pivot) r--;
		
			//nur tauschen wenn die gr��ere vor der kleineren Zahl steht
			if(l<=r) {
				hilf=array[l];
				array[l]=array[r];
				array[r]=hilf;
				l++;r--;
			}
		}
		while(l<=r);

		//Array aufteilen und weiter sortieren
		if(l<ende) myQSort2(array, l, ende);
		if(r>start) myQSort2(array, start, r);
		
	}
	
	
	private static int[] sortierenArray1(int[] myArray) {
	
		int help=0;
		boolean isSorted = false;
		
		do{
			isSorted = true;
			for(int i = 1; i < myArray.length; i++) {
				
				if(myArray[i-1] > myArray[i]) {
					
					help = myArray[i-1];
					myArray[i-1] = myArray[i];
					myArray[i] = help;
					
					isSorted = false;
				}
			}
		}while(!isSorted);
		
		return myArray;
	}
	

	private static void ausgebenArray(int[] myArray) {

		for (int i = 0; i < myArray.length; i++) {
			System.out.println("Zeile " + (i+1) + ": " + myArray[i]);
		}

	}

	
	private static int[] initialisierenArray(int[] myArray) {

		//abwechselnd mit 1 und 2 initialisieren
		for (int i = 0; i < myArray.length; i++) {
			myArray[i] = einlesenZahl();
		}
		return myArray;
	}

	
	private static short einlesenArraygroesse() {

		short zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Arraygr��e eingeben:");
		do {
			try {
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Short.parseShort(input); // throws exception

				if (zahl >= 0) {
					isOk = true;
				} else {
					System.out.println("Fehler, die Arraygr��e darf nicht negativ sein, \nbitte erneut eingeben:");
					isOk = false;
				}

			} catch (Exception ex) {
				System.out.println("Fehler, bitte Arraygr��e erneut eingeben:");
				isOk = false;
			}
		} while (!isOk);

		return zahl;
	}


	private static int einlesenZahl() {

		int zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Zahl eingeben:");
		do {
			try {
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Integer.parseInt(input); // throws exception
				isOk = true;
			} catch (Exception ex) {
				System.out.println("Fehler, bitte Zahl erneut eingeben:");
				isOk = false;
			}

		} while (!isOk);

		return zahl;
	}

}
