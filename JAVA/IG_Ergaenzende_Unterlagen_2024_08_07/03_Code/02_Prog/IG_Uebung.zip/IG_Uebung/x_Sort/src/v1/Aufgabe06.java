package v1;
import java.util.Scanner;

public class Aufgabe06
{
	public static void main(String[] args)
	{
		// kombinierter Methodenaufruf
		ausgabe(berechne(eingabe(), eingabe()));
	}

	private static int eingabe()
	{

		int zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Zahl eingeben:");
		do
		{
			try
			{
				zahl = new Scanner(System.in).nextInt();
				isOk = true;
			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Zahl erneut eingeben:");
				isOk = false;
			}

		} while (!isOk);

		return zahl;
	}

	private static int berechne(int zahl1, int zahl2)
	{

		return zahl1 * zahl2;
	}

	private static void ausgabe(int zahl)
	{

		System.out.println("Ausgabe: " + zahl);
	}

}
