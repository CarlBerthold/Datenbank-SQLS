package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Aufgabe10
{

	public static void main(String[] args)
	{

		// Primzahlen ausgeben bis user-input
		ausgebenPrimzahlen(einlesenZahl());

	}

	private static void ausgebenPrimzahlen(int bisZahl)
	{
		if (bisZahl < 2)
		{
			System.out.println("Es gibt keine Primzahlen die kleiner als 2 sind!");
			return;
		}

		for (int i = 2; i <= bisZahl; i++)
		{
			if (istPrimzahl(i))
			{
				System.out.println(i);
			}
		}
	}

	private static boolean istPrimzahl(int zahl)
	{
		// Def.: Primzahlen sind alle nat�rlichen Zahlen die
		// gr��er als 1 und nur durch 1 und sich selbst teilbar sind.

		// Zahlen kleiner 2 sind keine Primzahlen
		if (zahl < 2)
			return false;

		// 2 ist die einzige gerade Primzahl
		if (zahl == 2)
			return true;

		// alle anderen geraden Zahlen ausschlie�en
		if (zahl % 2 == 0)
			return false;

		// Teilbarkeit f�r ungerade Zahlen pr�fen
		// nur bis zur H�lfte der zu pr�fenden Zahl,
		// denn keine Zahl > testZahl/2 kann Teiler von testZahl sein
		for (int i = 3; i <= (zahl / 2); i += 2)
		{
			if (zahl % i == 0)
				return false;
		}

		// keinen Teiler gefunden
		return true;
	}

	private static int einlesenZahl()
	{

		int zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Zahl eingeben:");
		do
		{
			try
			{
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Integer.parseInt(input); // throws exception
				isOk = true;
			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Zahl erneut eingeben:");
				isOk = false;
			}

		} while (!isOk);

		return zahl;
	}
}
