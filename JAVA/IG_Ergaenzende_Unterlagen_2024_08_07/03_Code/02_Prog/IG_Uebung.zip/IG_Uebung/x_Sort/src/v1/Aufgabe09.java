package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Aufgabe09
{

	public static void main(String[] args)
	{

		// Array erzeugen (deklarieren), Arraygr��e von Konsole einlesen und Speicher
		// reservieren
		int[] myArray = new int[einlesenArraygroesse()];

		// Array initialisieren (wenn gr��er 0)
		initialisierenArray(myArray);

		// Array ausgeben
		if (myArray.length > 0)
		{
			ausgebenArray(myArray);
		} else
		{
			System.out.println("Array ist leer!");
		}
	}

	private static void ausgebenArray(int[] myArray)
	{

		for (int i = 0; i < myArray.length; i++)
		{
			System.out.println("Zeile " + (i + 1) + ": " + myArray[i]);
		}

	}

	private static void initialisierenArray(int[] myArray)
	{

		// abwechselnd mit 1 und 2 initialisieren
		for (int i = 0; i < myArray.length; i++)
		{
			myArray[i] = (i % 2) + 1;
		}
	}

	private static short einlesenArraygroesse()
	{

		short zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Arraygr��e eingeben:");
		
		do
		{
			try
			{
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Short.parseShort(input); // throws exception

				if (zahl >= 0)
				{
					isOk = true;
				} else
				{
					System.out.println("Fehler, die Arraygr��e darf nicht negativ sein, \nbitte erneut eingeben:");
					isOk = false;
				}

			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Arraygr��e erneut eingeben:");
				isOk = false;
			}
		} while (!isOk);

		return zahl;
	}

}
