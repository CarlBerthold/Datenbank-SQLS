package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Aufgabe11
{

	public static void main(String[] args)
	{

		// zwei Zahlen einlesen und GGT ausgeben
		// System.out.println("GGT: " + findeGGT1(einlesenZahl(), einlesenZahl()));

		// zwei Zahlen einlesen und GGT ausgeben
		// System.out.println("GGT: " + findeGGT2(einlesenZahl(), einlesenZahl()));

		// speed test
		int zahl1 = einlesenZahl(), zahl2 = einlesenZahl();
		long start = 0, ende = 0;

		// ggT1
		start = System.nanoTime();
		for (int i = 0; i < 1000; i++)
			findeGGT1(zahl1, zahl2);
		ende = System.nanoTime();
		System.out.println("ggT1: " + (ende - start));

		// ggT2
		start = System.nanoTime();
		for (int i = 0; i < 1000; i++)
			findeGGT2(zahl1, zahl2);
		ende = System.nanoTime();
		System.out.println("ggT2: " + (ende - start));

	}

	private static int findeGGT1(int zahl1, int zahl2)
	{

		// Def.: Der ggT ist die gr��te Zahl, durch die beide Zahlen ohne Rest geteilt
		// werden k�nnen.

		// Den Betrag der Zahlen bilden, falls diese negativ sind
		if (zahl1 < 0)
			zahl1 = zahl1 * -1;
		if (zahl2 < 0)
			zahl2 = zahl2 * -1;

		// 0 ist durch alle Zahlen teilbar,
		// daher entspricht die jeweils andere Zahl dem ggT
		if (zahl1 == 0)
			return zahl2;
		if (zahl2 == 0)
			return zahl1;

		while (zahl1 != zahl2)
		{
			zahl1 = zahl1 > zahl2 ? zahl1 - zahl2 : zahl1;
			zahl2 = zahl2 > zahl1 ? zahl2 - zahl1 : zahl2;
		}

		return zahl1;

	}

	private static int findeGGT2(int zahl1, int zahl2)
	{

		// Def.: Der ggT ist die gr��te Zahl, durch die beide Zahlen ohne Rest geteilt
		// werden k�nnen.

		// 0 ist durch alle Zahlen teilbar,
		// daher entspricht die jeweils andere Zahl dem ggT
		if (zahl1 == 0)
			return (zahl2 >= 0 ? zahl2 : zahl2 * -1); // Betrag zur�ckgeben, wird hier nicht vorher gepr�ft

		// unn�tig wegen kopfgesteuerter Schleife
		// if(zahl2 == 0) return zahl1;

		int hilf = 0;
		// teilen bis Rest 0
		while (zahl2 != 0)
		{
			hilf = zahl1 % zahl2;
			zahl1 = zahl2;
			zahl2 = hilf;
		}

		// Den Betrag von Zahl1 zur�ckgeben
		return (zahl1 > 0 ? zahl1 : zahl1 * -1);
	}

	private static int einlesenZahl()
	{

		int zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Zahl eingeben:");
		do
		{
			try
			{
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Integer.parseInt(input); // throws exception
				isOk = true;
			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Zahl erneut eingeben:");
				isOk = false;
			}

		} while (!isOk);

		return zahl;
	}

}
