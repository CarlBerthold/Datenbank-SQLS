package v1;

import java.util.ArrayList;

public class Aufgabe15
{

	// Enumeration f�r loescheZahlen()
	private enum myOp
	{
		GREATER_THAN, GREATER_OR_EQUAL, LESS_THAN, LESS_OR_EQUAL, EQUAL, UNEQUAL
	}

	public static void main(String[] args)
	{

		// vorgegebenes Array

		int[] myArray = new int[]
		{ 234, 3, 466, 1, 9, 5 };

		myArray = loescheZahlen(myArray, myOp.GREATER_THAN, 100);

		ausgebenArray(sortierenArray(myArray));

	}

	private static int[] loescheZahlen(int[] myArray, myOp vergleichsOp, int zahl)
	{

		// workaround due to missing Array.removeElement() method or something similar
		ArrayList<Integer> list = new ArrayList<Integer>();

		// get elements which should remain in array
		switch (vergleichsOp)
		{
		case GREATER_THAN:
			for (int i = 0; i < myArray.length; i++)
			{
				if (myArray[i] <= zahl)
				{
					list.add(myArray[i]);
				}
			}
			break;
		case GREATER_OR_EQUAL:
			for (int i = 0; i < myArray.length; i++)
			{
				if (myArray[i] < zahl)
				{
					list.add(myArray[i]);
				}
			}
			break;
		case LESS_THAN:
			for (int i = 0; i < myArray.length; i++)
			{
				if (myArray[i] >= zahl)
				{
					list.add(myArray[i]);
				}
			}
			break;
		case LESS_OR_EQUAL:
			for (int i = 0; i < myArray.length; i++)
			{
				if (myArray[i] > zahl)
				{
					list.add(myArray[i]);
				}
			}
			break;
		case EQUAL:
			for (int i = 0; i < myArray.length; i++)
			{
				if (myArray[i] != zahl)
				{
					list.add(myArray[i]);
				}
			}
			break;
		case UNEQUAL:
			for (int i = 0; i < myArray.length; i++)
			{
				if (myArray[i] == zahl)
				{
					list.add(myArray[i]);
				}
			}
			break;
		default: // prevented due to enum myOp
			break;
		}

		// copy elements to new array
		myArray = new int[list.size()];
		for (int i = 0; i < myArray.length; i++)
		{
			myArray[i] = list.get(i);
		}

		return myArray;
	}

	private static int[] sortierenArray(int[] myArray)
	{

		myQSort(myArray, 0, myArray.length - 1);

		return myArray;
	}

	private static void myQSort(int[] array, int start, int ende)
	{

		int l = start, r = ende, hilf = 0;

		// zuf�lliges Element aus der Mitte des Arrays,
		// um die Arraygr��e schnellstm�glich zu verkleinern
		int pivot = array[(l + r) / 2];

		// einmal das Array durchlaufen (l>r)
		do
		{
			// von au�en das erste element suchen, dass kleiner/gr��er ist als pivot
			while (l < ende && array[l] < pivot)
				l++;
			while (r > start && array[r] > pivot)
				r--;

			// nur tauschen wenn die gr��ere vor der kleineren Zahl steht
			if (l <= r)
			{
				hilf = array[l];
				array[l] = array[r];
				array[r] = hilf;
				l++;
				r--;
			}
		} while (l <= r);

		// Array aufteilen und weiter sortieren
		if (l < ende)
			myQSort(array, l, ende);
		if (r > start)
			myQSort(array, start, r);

	}

	private static void ausgebenArray(int[] myArray)
	{

		for (int i = 0; i < myArray.length; i++)
		{
			System.out.println("Zeile " + (i + 1) + ": " + myArray[i]);
		}

	}

}
