package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Aufgabe12
{

	public static void main(String[] args)
	{

		System.out.println("kgV: " + findeKGV1(einlesenZahl(), einlesenZahl()));

	}

	private static long findeKGV1(int zahl1, int zahl2)
	{

		// Def.: kgV, kleinste positive Zahl, die ein Vielfaches beider Zahlen darstellt
		// Anmerkung: der Faktor kann auch negativ sein, sodass es auch ein kgV f�r zwei
		// negative Zahlen gibt

		// wenn eine der beiden Zahlen 0 ist, ist das kgV per Definition auch 0
		if (zahl1 == 0 || zahl2 == 0)
			return 0;

		// Die Faktoren m�ssen das gleiche Vorzeichen haben wie die Zahlen,
		// damit das Vielfache positiv ist
		int f1 = (zahl1 > 0 ? 1 : -1), f2 = (zahl2 > 0 ? 1 : -1);
		long v1 = zahl1 * f1 // das Vielfache von Zahl1
				, v2 = zahl2 * f2; // das Vielfache von Zahl2

		// wenn zahl1 ein Vielfaches von zahl2 ist, oder andersrum
		if (v1 > v2)
		{
			if (v1 % v2 == 0)
			{
				return v1;
			}
		} else
		{
			if (v2 % v1 == 0)
			{
				return v2;
			}
		}

		// vermutlich schei�e langsam, aber mir f�llt grad nix anderes ein
		while (v1 != v2)
		{

			// �ndere den Faktor f�r das kleinere Vielfache und berechne neu
			if (v1 < v2)
			{
				v1 = (zahl1 > 0 ? (zahl1 * ++f1) : (zahl1 * --f1));
			} else
			{
				v2 = (zahl2 > 0 ? (zahl2 * ++f2) : (zahl2 * --f2));
			}

			// �berlauf verhindern
			if (f1 == Integer.MAX_VALUE || f2 == Integer.MAX_VALUE || f1 == Integer.MIN_VALUE
					|| f2 == Integer.MIN_VALUE)
				return -1;
		}

		return v1; // egal ob v1 oder v2, beide sind gleich
	}

	private static int einlesenZahl()
	{

		int zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Zahl eingeben:");
		do
		{
			try
			{
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				zahl = Integer.parseInt(input); // throws exception
				isOk = true;
			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Zahl erneut eingeben:");
				isOk = false;
			}

		} while (!isOk);

		return zahl;
	}

}
