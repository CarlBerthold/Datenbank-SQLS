package v2;

public class Program
{
	public static void main(String[] args)
	{
		Person objektPerson = new Person(); 
		
		objektPerson.name = "Hans Mueller";
		objektPerson.alter= 32;
		objektPerson.wohnort = "Koeln";
		
		objektPerson.Ausgabe();
	}

}
