package v4;

public class Program
{
	public static void main(String[] args)
	{
		Auto objektAuto = new Auto("VW Golf V", 2010, 35000);
		
		objektAuto.Ausgabe();
	}
}
