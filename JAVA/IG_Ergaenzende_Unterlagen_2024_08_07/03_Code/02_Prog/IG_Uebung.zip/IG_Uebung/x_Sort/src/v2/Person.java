package v2;
public class Person
{
	public String name;
	public int alter;
	public String wohnort;


	public void Ausgabe()
	{
		System.out.println("Name: " + name + "\nAlter: " + alter + "\nWohnort: " + wohnort);
	}
}
