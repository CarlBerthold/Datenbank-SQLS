package v4;
public class Auto
{
	private String herstellername;
	private int baujahr;
	private int kilometeranzahl;
	
	public Auto(String herstellername, int baujahr, int kilometeranzahl)
	{
		this.herstellername = herstellername;
		this.baujahr = baujahr;
		this.kilometeranzahl = kilometeranzahl;
	}

	public void Ausgabe()
	{
		System.out.println("Herstellername: " + herstellername + "\nBaujahr: " + baujahr + "\nKilometeranzahl: "
				+ kilometeranzahl);
	}
}
