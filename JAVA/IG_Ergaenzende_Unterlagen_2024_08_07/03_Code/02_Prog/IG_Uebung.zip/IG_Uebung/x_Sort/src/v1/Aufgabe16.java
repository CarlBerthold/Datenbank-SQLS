package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class Aufgabe16
{

	public static void main(String[] args)
	{

		// create a new array
		int[] myArray = new int[readArraySizeFromConsole("Bitte Arraygr��e angeben!")];

		// initialise the array with random numbers
		initialiseArrayRandomly(myArray);

		// sort the array
		sortMyArray(myArray, sortingMethod.QUICK_SORT, sortingDirection.UPWARDS);

		// print the array to the console
		printArrayToConsole(myArray);

		// find a value
		int index = findMyValue(myArray, searchingMethod.BINARY_SEARCH, WELL_KNOWN_SEARCH_VALUE);
		if (index < 0)
		{
			System.out.println("Sorry, could'n find it!");
		} else
		{
			System.out.println("Found it at index: " + index + " | Line: " + (index + 1));
		}

	}

	private enum searchingMethod
	{
		BINARY_SEARCH, LINEAR_SEARCH
	}

	private static int findMyValue(int[] anArray, searchingMethod sMethod, int value)
	{

		int index = -1;
		// using switch for potentially extension
		switch (sMethod)
		{
		case BINARY_SEARCH:
			sortMyArray(anArray, sortingMethod.QUICK_SORT, sortingDirection.UPWARDS);
			index = binarySearch(anArray, value, 0, anArray.length - 1);
			break;
		case LINEAR_SEARCH:
			index = linearSearch(anArray, value);
			break;
		}
		return index;
	}

	private static int binarySearch(int[] anSortedArray, int value, int start, int end)
	{
		int index = -1;
		int pivot = (start + end) / 2;

		if (anSortedArray[pivot] == value)
			return pivot;

		if (anSortedArray[pivot] < value)
		{
			index = binarySearch(anSortedArray, value, pivot, end);
		} else
		{
			index = binarySearch(anSortedArray, value, start, pivot);
		}

		return index;
	}

	private static int linearSearch(int[] anArray, int value)
	{

		for (int i = 0; i < anArray.length; i++)
		{
			if (anArray[i] == value)
				return i;
		}

		// value not found
		return -1;
	}

	private enum sortingDirection
	{
		UPWARDS, DOWNWARDS
	}

	private enum sortingMethod
	{
		BUBBLE_SORT, QUICK_SORT
	}

	private static void sortMyArray(int[] anArray, sortingMethod sMethod, sortingDirection sDirection)
	{

		// using switch for potentially extension
		switch (sMethod)
		{
		case BUBBLE_SORT:
			directedBubbleSort(anArray, sDirection);
			break;
		case QUICK_SORT:
			directedQuicksort(anArray, 0, anArray.length - 1, sDirection);
			break;
		}
	}

	private static void directedBubbleSort(int[] anArray, sortingDirection sDirection)
	{

		int help = 0;
		boolean isSorted = false;

		do
		{
			isSorted = true;
			for (int i = 1; i < anArray.length; i++)
			{

				if (sDirection == sortingDirection.UPWARDS)
				{
					// upwards
					if (anArray[i - 1] > anArray[i])
					{

						help = anArray[i - 1];
						anArray[i - 1] = anArray[i];
						anArray[i] = help;

						isSorted = false;
					}
				} else
				{
					// downwards
					if (anArray[i - 1] < anArray[i])
					{

						help = anArray[i - 1];
						anArray[i - 1] = anArray[i];
						anArray[i] = help;

						isSorted = false;
					}
				}
			}
		} while (!isSorted);
	}

	private static void directedQuicksort(int[] anArray, int start, int end, sortingDirection sDirection)
	{

		int left = start, right = end, help = 0;
		int pivot = anArray[(left + right) / 2];

		do
		{
			if (sDirection == sortingDirection.UPWARDS)
			{
				// upwards
				while (left < end && anArray[left] < pivot)
					left++;
				while (right > start && anArray[right] > pivot)
					right--;
			} else
			{
				// downwards
				while (left < end && anArray[left] > pivot)
					left++;
				while (right > start && anArray[right] < pivot)
					right--;
			}

			if (left <= right)
			{
				help = anArray[left];
				anArray[left] = anArray[right];
				anArray[right] = help;
				left++;
				right--;
			}
		} while (left <= right);

		if (left < end)
			directedQuicksort(anArray, left, end, sDirection);
		if (right > start)
			directedQuicksort(anArray, start, right, sDirection);
	}

	private static void printArrayToConsole(int[] anArray)
	{

		for (int i = 0; i < anArray.length; i++)
		{
			System.out.println("Line " + (i + 1) + ": " + anArray[i]);
		}
	}

	private final static int WELL_KNOWN_SEARCH_VALUE = 42;

	private static void initialiseArrayRandomly(int[] anArray)
	{

		Random rand = new Random();
		for (int i = 0; i < anArray.length; i++)
		{
			anArray[i] = rand.nextInt();
		}

		// allows to search a well-known value
		if (anArray.length > 0)
			anArray[0] = WELL_KNOWN_SEARCH_VALUE;
	}

	private static int readArraySizeFromConsole(String message)
	{

		int value = 0;

		do
		{
			value = readNumberFromConsole(message);

			if (value < 0)
			{
				System.out.println("Sorry, but the array-size must have a positive value!");
			}
		} while (value < 0);

		return value;
	}

	private static int readNumberFromConsole(String message)
	{

		int value = 0;
		boolean isOk = false;
		System.out.println(message);
		System.out.println("Please input a value: ");

		do
		{
			try
			{
				String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
				value = Integer.parseInt(input); // throws exception on error
				isOk = true;
			} catch (Exception ex)
			{
				System.out.println("Sorry an error occurred!");
				System.out.println(message);
				System.out.println("Please input the value again: ");
				isOk = false;
			}
		} while (!isOk);

		return value;
	}

}
