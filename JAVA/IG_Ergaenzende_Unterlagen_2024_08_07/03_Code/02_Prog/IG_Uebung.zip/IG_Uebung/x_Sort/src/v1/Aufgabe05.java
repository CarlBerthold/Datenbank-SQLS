package v1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Aufgabe05
{
	public static void main(String[] args)
	{

		// Array erzeugen (deklarieren)
		int[] myArray;

		// Arraygr��e von Konsole einlesen
		short size = einlesenArraygroesse();

		// Arraygr��e festlegen (Speicher allokieren)
		myArray = new int[size];

		// Array initialisieren (wenn gr��er 0)
		// kopfgesteuerte Schleife - geht auch ohne if
		// if(myArray.length >0) {
		initialisierenArray(myArray);
		// }

		// Array ausgeben
		if (myArray.length > 0)
		{
			ausgebenArray(myArray);
		} else
		{
			System.out.println("Array ist leer!");
		}
	}

	private static void ausgebenArray(int[] myArray)
	{

		for (int i = 1; i <= myArray.length; i++)
		{
			System.out.println("Zeile " + i + ": " + myArray[i - 1]);
		}

	}

	private static void initialisierenArray(int[] myArray)
	{

		Random rand = new Random();
		for (int i = 0; i < myArray.length; i++)
		{
			myArray[i] = rand.nextInt();
		}
	}

	private static short einlesenArraygroesse()
	{

		short zahl = 0;
		boolean isOk = false;
		System.out.println("Bitte Arraygr��e eingeben:");
		do
		{
			try
			{
				InputStreamReader reader = new InputStreamReader(System.in);
				BufferedReader buffer = new BufferedReader(reader);
				String input = buffer.readLine();
				zahl = Short.parseShort(input); // throws exception

				if (zahl >= 0)
				{
					isOk = true;
				} else
				{
					System.out.println("Fehler, die Arraygr��e darf nicht negativ sein, \nbitte erneut eingeben:");
					isOk = false;
				}

			} catch (Exception ex)
			{
				System.out.println("Fehler, bitte Arraygr��e erneut eingeben:");
				isOk = false;
			}
		} while (!isOk);

		return zahl;
	}
}
