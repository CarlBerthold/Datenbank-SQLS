package Aufgabe_04;
/*
    Bitte schreiben Sie ein Programm, welches von dem User die folgenden Informationen abfragt:
            - Vorname Nachname
            - Straße 
            - Hausnummer
            - PLZ
            - Ort
            
    Geben Sie die Daten wie folgt aus:
    
    Vorname:		Peter 
    Nachname:		Mueller
    Adresse:		Hauptstraße 1
    				51107 Köln 
*/


public class Program
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
