package Aufgabe_05_v5;
/*
	1.	Schreiben Sie eine Methode mit dem Namen „Eingabe“, die eine Zahl von dem Benutzer 
		einliest und eine double Zahl zurückgibt. 

	2.	Schreiben Sie eine weitere Methode mit dem Namen „berechne“, die zwei Zahlen als 
		Parameter aufnimmt, diese Addiert, Subtrahiert, Muliipliziert oder Dividiert und
		als double zurückgibt. 

	3.	Schreiben Sie eine Methode mit dem Namen „Ausgabe“, die eine Zahl als Parameter 
		bekommt und dieses auf dem Bildschirm ausgibt. 

	4.	Rufen Sie die „Eingabe“-Methode zwei Mal auf und speichern Sie den jeweiligen 
		Wert in einer separaten double-Variable. 

	5.	Übergeben Sie die zuvor eingelesenen Variablen der „berechne“-Methode und lassen 
		Sie das Ergebnis von der „Ausgabe“-Methode ausgeben.
*/

import java.util.Scanner;

public class Program
{

	public static void main(String[] args)
	{

		// Methoden aufruf ----------------------------------- Version 1
		// Zahlen einlesen
		double ersteZahl = einlesenZahl();
		double zweiteZahl = einlesenZahl();

		// Operator einlesen
		char operator = einlesenOperator();

		// Berechnung durchfuehren
		double ergebnis = berechneErgebnis(ersteZahl, zweiteZahl, operator);

		// Ergebnis ausgeben
		ausgabeZahl(ergebnis);

		// Methoden aufruf ----------------------------------- Version 2
		// ausgabeZahl(berechneErgebnis(einlesenZahl(), einlesenZahl(), einlesenOperator()));
	}

	private static double einlesenZahl()
	{
		double zahl = 0;
		boolean isOk = false;
		
		String eingabe = "";
		Scanner sc = null;
		 
		System.out.print("Bitte Zahl eingeben: ");
		
		do
		{
			try
			{
				sc = new Scanner(System.in);
				eingabe = sc.next();
				
				zahl = Double.parseDouble(eingabe);
				
				isOk = true;
			} 
			catch (Exception ex)
			{
				System.out.print("Fehler, bitte nur Ziffern eingeben: ");
				isOk = false;
			}
		} while (!isOk);

		return zahl;
	}

	private static char einlesenOperator()
	{
		char operator = ' ';
		boolean isOk = false;
		
		String eingabe = "";
		Scanner sc = null;
		
		System.out.println("Bitte Operator eingeben:");
		do
		{
			try
			{
				sc = new Scanner(System.in);
				eingabe = sc.next();
				operator = eingabe.charAt(0); // throws exception

				if (operator == '+' || operator == '-' || operator == '*' || operator == ':')
				{
					isOk = true;
				} 
				else
				{
					System.out.println("Fehler, bitte Operator (+ - * :) erneut eingeben:");
					isOk = false;
				}
			}
			catch (Exception ex)
			{
				System.out.println("Fehler, bitte Operator erneut eingeben:");
				isOk = false;
			}
			
		} while (!isOk);

		return operator;
	}

	private static double berechneErgebnis(double zahl1, double zahl2, char operator)
	{
		double ergebnis = 0;
		switch (operator)
		{
		case '+':
			ergebnis = zahl1 + zahl2;
			break;
		case '-':
			ergebnis = zahl1 - zahl2;
			break;
		case '*':
			ergebnis = zahl1 * zahl2;
			break;
		case ':':
			ergebnis = zahl1 / zahl2;
			break;
		default:
			break;
		}
		return ergebnis;
	}

	private static void ausgabeZahl(double zahl)
	{
		System.out.println("Ausgabe: " + zahl);
	}

}
