package Aufgabe_02;
/*
	Schreiben Sie ein Programm, welches zwei Zahlen von dem benutzter einliest, addiert und als Summe ausgibt.
*/

import java.util.Scanner;

public class Program
{
	public static void main(String[] args)
	{
		int ersteZahl = 0, zweiteZahl = 0, ergebnis = 0;
		String eingabe = "";
		Scanner sc = new Scanner(System.in);	
		
		System.out.println("Bitte Zahl eingeben:");
		eingabe = sc.next();
		ersteZahl = Integer.parseInt(eingabe); 
		
		System.out.println("Bitte Zahl eingeben:");
		eingabe = sc.next();
		zweiteZahl = Integer.parseInt(eingabe);

		ergebnis =  ersteZahl + zweiteZahl;
			
		System.out.println("Ergebnis: " + ergebnis);
	}
}
