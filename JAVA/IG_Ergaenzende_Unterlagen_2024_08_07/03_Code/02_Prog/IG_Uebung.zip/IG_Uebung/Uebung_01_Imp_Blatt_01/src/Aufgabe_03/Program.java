package Aufgabe_03;
/*
	Lesen Sie zwei Zahlen vom Benutzer ein, vergleichen Sie diese und geben Sie die größere von beiden aus.
*/

import java.util.Scanner;


public class Program
{
	public static void main(String[] args)
	{
		int ersteZahl;
		int zweiteZahl;
		boolean proof;
		String eingabe;
		
		ersteZahl= 0;
		zweiteZahl = 0;
		proof = false;
		eingabe = "";
		
		Scanner sc = new Scanner(System.in);	
		
		System.out.print("Bitte Zahl eingeben:");
		eingabe = sc.next();
		ersteZahl = Integer.parseInt(eingabe); 
		
		System.out.print("Bitte Zahl eingeben:");
		eingabe = sc.next();
		zweiteZahl = Integer.parseInt(eingabe);

		proof =  (ersteZahl > zweiteZahl);
		
		if (proof)
		{
			System.out.println("1.Zahl ist groesser: " + ersteZahl);
		}
		else
		{
			System.out.println("2.Zahl ist greoesser: " + zweiteZahl);
		}
			
		
	}
}
