package Aufgabe_01;
/*
	Deklarieren Sie eine Ganze Zahl, initialisieren Sie mit 0 und geben Sie 
	die Zahl auf der Konsole aus. 
*/

public class Program
{

	public static void main(String[] args)
	{
		// Deklaration einer Ganzzahl
		int zahl;

		// Initialisierung mit 0
		zahl = 0;

		// Ausgabe auf Konsole
		System.out.println("Ausgabe:" + zahl);

	}

}
