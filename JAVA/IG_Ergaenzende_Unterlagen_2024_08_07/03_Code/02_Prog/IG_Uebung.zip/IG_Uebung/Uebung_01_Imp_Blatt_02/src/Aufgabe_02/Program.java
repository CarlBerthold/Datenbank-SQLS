package Aufgabe_02;
/*
	Bitte schreiben ein Programm, welches Kilogramm in Pfund umrechnet und umgekehrt: umrechnet: 
	-	Lesen Sie vom User einen Wert ein. 
	-	Fragen Sie den User, ob er den Wert in Pfund oder Kilogramm umrechnen möchte.
	-	Im Anschluss geben Sie dem User den Umgerechneten Wert aus. 
*/

import java.util.Scanner;

public class Program
{
	public static void main(String[] args)
	{
//		int ersteZahl = 0, zweiteZahl = 0, ergebnis = 0;
//		String eingabe = "";
//		Scanner sc = new Scanner(System.in);	
//		
//		System.out.println("Bitte Zahl eingeben:");
//		eingabe = sc.next();
//		ersteZahl = Integer.parseInt(eingabe); 
//		
//		System.out.println("Bitte Zahl eingeben:");
//		eingabe = sc.next();
//		zweiteZahl = Integer.parseInt(eingabe);
//
//		ergebnis =  ersteZahl + zweiteZahl;
//			
//		System.out.println("Ergebnis: " + ergebnis);
	}
}
