package Aufgabe_01;
/*
	Bitte schreiben Sie ein Programm, welches die Temperatur umrechnet: 
	-	Sie lesen vom User einen Grad Wert ein. 
	-	Fragen Sie den User, ob er den Wert in Kelvin oder in Fahrenheit umrechnen will.
	-	Im Anschluss geben Sie dem User den Umgerechnet Wert auf der Konsole aus. 

*/

public class Program
{

	public static void main(String[] args)
	{
		// Deklaration einer Ganzzahl
		int zahl;

		// Initialisierung mit 0
		zahl = 0;

		// Ausgabe auf Konsole
		System.out.println("Ausgabe:" + zahl);

	}

}
