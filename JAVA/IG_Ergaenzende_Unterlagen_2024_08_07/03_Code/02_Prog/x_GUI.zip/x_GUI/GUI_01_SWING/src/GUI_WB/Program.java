package GUI_WB;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Program extends JFrame
{

	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private JTextField txtfZahlEins;
	private JTextField txtfZahlZwei;
	private JTextField txtfErgebnis;
	private JLabel lblErgbenis;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					Program frame = new Program();
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Program()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 217);
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(panel);
		panel.setLayout(null);
		
		JButton btnRechne = new JButton("Addieren");
		btnRechne.addMouseListener(new MouseAdapter() 
		{
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				txtfZahlEins.setText("saffa");
			}
		});
		
		
		btnRechne.addMouseMotionListener(new MouseAdapter() 
		{
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				txtfZahlEins.setText("saffa");
			}
		});
		
		
		btnRechne.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnRechne.setBounds(22, 115, 360, 44);
		panel.add(btnRechne);
		
		txtfZahlEins = new JTextField();
		txtfZahlEins.setBounds(22, 44, 144, 19);
		panel.add(txtfZahlEins);
		txtfZahlEins.setColumns(10);
		
		JLabel lblOperator = new JLabel("+");
		lblOperator.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblOperator.setBounds(193, 45, 10, 13);
		panel.add(lblOperator);
		
		txtfZahlZwei = new JTextField();
		txtfZahlZwei.setBounds(231, 44, 151, 19);
		panel.add(txtfZahlZwei);
		txtfZahlZwei.setColumns(10);
		
		txtfErgebnis = new JTextField();
		txtfErgebnis.setBounds(54, 77, 328, 19);
		panel.add(txtfErgebnis);
		txtfErgebnis.setColumns(10);
		
		lblErgbenis = new JLabel("=");
		lblErgbenis.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblErgbenis.setBounds(22, 78, 10, 13);
		panel.add(lblErgbenis);
	}
}
