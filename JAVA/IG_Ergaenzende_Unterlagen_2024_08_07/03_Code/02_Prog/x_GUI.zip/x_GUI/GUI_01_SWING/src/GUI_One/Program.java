package GUI_One;

import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Program extends JFrame
{
	private static final long serialVersionUID = 1L;
	
	JPanel panel;
	JButton btn;
	JLabel lbl;
	 
	public Program()
	{
		setTitle("First GUI");
		setSize(500,300);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		panel = new JPanel();
		btn = new JButton();
		lbl = new JLabel();
		
		btn.setText("Klick Mich !");
		
		
		
		// Event Listener für den Button --> Registrieren 
		btn.addMouseListener
		(
			new java.awt.event.MouseAdapter()
			{
				// Wenn die Mouse geklickt wird, dann rufe die Methode --> "btnMouseClicked(ae)" auf.  
				@Override
				public void mouseClicked (java.awt.event.MouseEvent  ae)
				{
					btnMouseClicked(ae);
				}
//				public void mousePressed (java.awt.event.MouseEvent  ae)
//				{
//					btnMouseClicked(ae);
//				}
//				public void mouseReleased (java.awt.event.MouseEvent  ae)
//				{
//					btnMouseClicked(ae);
//				}
//				public void mouseEntered (java.awt.event.MouseEvent  ae)
//				{
//					btnMouseEntered(ae);
//				}
//				public void mouseExited (java.awt.event.MouseEvent  ae)
//				{
//					btnMouseExited(ae);
//				}
			}
		);
		
		panel.add(btn);	
		panel.add(lbl);
		add(panel);	
		setVisible(true);
	}
	
	private void btnMouseClicked(java.awt.event.MouseEvent ae)
	{	
		lbl.setText("Hello World ! ");
		
		// System.out.println(ae.getClickCount());
	}
	
//	private void btnMouseEntered(java.awt.event.MouseEvent ae)
//	{
//		lbl.setText("Button wurde betereten.");
//	}
//	
//	private void btnMouseExited(java.awt.event.MouseEvent ae)
//	{
//		lbl.setText("Button wurde verlassen.");
//	}
	
	public static void main (String args[])
	{
		// Wir erzeugen einen neuen Thread
		java.awt.EventQueue.invokeLater
		(
			new Runnable()
			{
				// Die Methode muss beim verwenden von Runnable überschreiben werden.   
				@Override
				public void run()
				{
					// erzeugen eines neuen Frames
					new Program(); 			
				}
				
			}
		);	
	}
}
