/**
 * 
 */
/**
 * 
 */
module GUI
{
	requires java.desktop;
}